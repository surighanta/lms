from flask import Flask, render_template,request,make_response,redirect,url_for
import requests
import MySQLdb
from datetime import date
import calendar
import time

app = Flask(__name__)

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/auth',methods=['POST'])
def auth():
    if request.method == "POST":
        details = request.form
        username = details['username']
        password = details['password']
        db = MySQLdb.connect(host="localhost",    # your host, usually localhost
                     user="flask",         # your username
                     passwd="flaskUSER!@#$%12345",  # your password
                     db="lms")        # name of the data base
        cur = db.cursor()
        cur.execute("SELECT name,role FROM users WHERE userid=%s AND password=%s;",(username,password))
        if cur.rowcount == 0:
            db.close()
            return render_template('loginerror.html')
        else:
            for row in cur.fetchall():
                name = row[0]
                role = row[1]
        db.close()
        if role == 'admin':
            response = redirect(url_for('managerview'),code=307)
            response.set_cookie('username', username)
            response.set_cookie('name', name)
            return response
        else:
            response = redirect(url_for('employeeview'),code=307)
            response.set_cookie('username', username)
            response.set_cookie('name', name)
            return response

@app.route('/employeeview',methods=['POST'])
def employeeview():
    if request.method == "POST":
        details = request.form
        username = details['username']
    db = MySQLdb.connect(host="localhost",    # your host, usually localhost
                     user="flask",         # your username
                     passwd="flaskUSER!@#$%12345",  # your password
                     db="lms")        # name of the data base
    cur = db.cursor()
    cur.execute("SELECT name FROM users WHERE userid=%s;",(username,))
    if cur.rowcount > 0:
        for row in cur.fetchall():
            name = row[0]
    userLeaves = []
    cur.execute("SELECT * FROM leaves WHERE userid=%s ORDER BY leavedate DESC;",(username,))
    columns = [column[0] for column in cur.description]
    if cur.rowcount > 0:
        for row in cur.fetchall():
            userLeaves.append(dict(zip(columns, row)))
    cur.execute("SELECT nodays FROM leaves WHERE userid=%s AND (status=%s OR status=%s);",(username,'Approved','Pending'))
    totalUsed = 0
    if cur.rowcount > 0:
        for row in cur.fetchall():
            totalUsed += row[0]
    db.close()
    return render_template('empdashboard.html',result=userLeaves,name=name,username=username,totalUsed=totalUsed)

@app.route('/applyleave',methods=['POST'])
def applyleave():
    details = request.form
    leavedate = details['startdate']
    nodays = details['nodays']
    username = details['username']
    totalUsed = details['totalUsed']
    totalUsed = int(totalUsed,10)
    nodays = int(nodays,10)
    if((totalUsed + nodays) > 21):
        return render_template('leavelimit.html',used=totalUsed,balance=(21-totalUsed))
    now = calendar.timegm(time.gmtime())
    leaveid = str(now) + username
    applydate = date.today()
    status = 'Pending'
    db = MySQLdb.connect(host="localhost",    # your host, usually localhost
                     user="flask",         # your username
                     passwd="flaskUSER!@#$%12345",  # your password
                     db="lms")        # name of the data base
    cur = db.cursor()
    cur.execute("INSERT INTO leaves (leaveid,userid,applydate,leavedate,nodays,status) VALUES (%s,%s,%s,%s,%s,%s);",(leaveid,username,applydate,leavedate,nodays,status))
    db.commit()
    db.close()
    response = redirect(url_for('employeeview'),code=307)
    return response

@app.route('/managerview',methods=['POST'])
def managerview():
    if request.method == "POST":
        details = request.form
        username = details['username']
    db = MySQLdb.connect(host="localhost",    # your host, usually localhost
                     user="flask",         # your username
                     passwd="flaskUSER!@#$%12345",  # your password
                     db="lms")        # name of the data base
    cur = db.cursor()
    cur.execute("SELECT name FROM users WHERE userid=%s;",(username,))
    if cur.rowcount > 0:
        for row in cur.fetchall():
            name = row[0]
    pendingLeaves = []
    cur.execute("SELECT * FROM leaves WHERE status='Pending' ORDER BY leavedate DESC;")
    columns = [column[0] for column in cur.description]
    if cur.rowcount > 0:
        for row in cur.fetchall():
            pendingLeaves.append(dict(zip(columns, row)))

    allLeaves = []
    cur.execute("SELECT * FROM leaves WHERE status!='Pending' ORDER BY leavedate DESC;")
    columns = [column[0] for column in cur.description]
    if cur.rowcount > 0:
        for row in cur.fetchall():
            allLeaves.append(dict(zip(columns, row)))
    db.close()
    return render_template('managerdashboard.html',result=allLeaves,pending=pendingLeaves,name=name,username=username)

@app.route('/action',methods=['POST'])
def action():
    if request.method == "POST":
        details = request.form
        username = details['username']
        leaveid = details['leaveid']
        action = details['action']
        role = details['role']
        comment = details['comment']
        referer = details['referer']
    actiondate = date.today()
    db = MySQLdb.connect(host="localhost",    # your host, usually localhost
                     user="flask",         # your username
                     passwd="flaskUSER!@#$%12345",  # your password
                     db="lms")        # name of the data base
    cur = db.cursor()
    cur.execute("UPDATE leaves SET status=%s, approvedby=%s,approveddate=%s,comment=%s WHERE leaveid = %s;",(action,username,actiondate,comment,leaveid))
    db.commit()
    db.close()
    response = redirect(url_for(referer),code=307)
    return response
